import Skill from "../models/Skill.js";

export const createSkill = async (req, res) => {
  const data = await Skill.create(req.body);
  res.json(data);
};

export const getSkills = async (req, res) => {
  const data = await Skill.find();
  res.json(data);
};

export const getSkill = async (req, res) => {
  const data = await Skill.findById(req.params.id);
  res.json(data);
};

export const updateSkill = async (req, res) => {
  const data = await Skill.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(data);
};

export const deleteSkill = async (req, res) => {
  await Skill.findByIdAndDelete(req.params.id);
  res.json({ msg: "Deleted" });
};