import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

import contactRoutes from "./routes/contactRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import portfolioRoutes from "./routes/portfolioRoutes.js";
import skillRoutes from "./routes/skillRoutes.js";
import serviceRoutes from "./routes/serviceRoutes.js";
import testimonialRoutes from "./routes/testimonialRoutes.js";
import cvRoutes from "./routes/cvRoutes.js";
import connectDB from "./config/db.js";

const app = express();

dotenv.config();
connectDB();

/* ✅ DEBUG LOGGER */
app.use((req, res, next) => {
  console.log("Incoming:", req.method, req.url);
  next();
});

/* ✅ ✅ ✅ SINGLE CLEAN CORS CONFIG */
app.use(cors({
  origin: "http://localhost:5173",
  methods: ["GET", "POST", "PUT", "DELETE"],
  allowedHeaders: ["Content-Type", "Authorization"]
}));

/* ✅ BODY PARSER */
app.use(express.json());

/* ✅ STATIC */
app.use("/uploads", express.static("uploads"));

/* ✅ ROUTES */
app.use("/api/contact", contactRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/portfolio", portfolioRoutes);
app.use("/api/skills", skillRoutes);
app.use("/api/services", serviceRoutes);
app.use("/api/testimonials", testimonialRoutes);
app.use("/api/cv", cvRoutes);

/* ✅ SERVER */
app.listen(process.env.PORT, () => {
  console.log(`🚀 Server running on port ${process.env.PORT}`);
});