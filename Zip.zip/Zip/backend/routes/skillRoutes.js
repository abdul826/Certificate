import express from "express";
import {
  createSkill,
  getSkills,
  getSkill,
  updateSkill,
  deleteSkill
} from "../controllers/skillController.js";

import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/addskill", createSkill);
router.get("/", getSkills);
router.get("/:id", getSkill);
router.put("/:id", protect,updateSkill);
router.delete("/:id", protect,deleteSkill);

export default router;