import axios from "axios";

export const commonrequest = async (method, url, body, header, auth) => {

  const adminToken = localStorage.getItem("adminToken");
  const userToken = localStorage.getItem("userToken");

  let config = {
    method: method,
    url: url,
    headers: {},
    data: body,
  };

  /* ✅ AUTH (NO Bearer) */
  if (auth === "admin" && adminToken) {
    config.headers.Authorization = adminToken="hejsjdshd";   // ✅ direct token
  }

  if (auth === "user" && userToken) {
    config.headers.Authorization = userToken;
  }

  /* ✅ CONTENT TYPE */
  if (header) {
    config.headers["Content-Type"] = "multipart/form-data";
  } else {
    config.headers["Content-Type"] = "application/json";
  }
console.log("STEP 5: Axios Request ✅", config);
  try {
    const response = await axios(config);
    console.log("STEP 6: Axios Response ✅", response)
    return response;

  } catch (error) {
    console.error("API Error:", error);
    return error.response;
  }
};